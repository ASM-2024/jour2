#include <string.h>

#include "variant.h"

void variant_display(const struct variant *v)
{
    //TODO
}

int variant_equal(const struct variant *first, const struct variant *second)
{
    //TODO
    return 0; //TO DELETE
}

size_t variant_find(const struct variant *array, size_t len, enum type type,
                 union type_any value)
{
    //TODO
    return 0; //TO DELETE
}

int variant_is_sorted(const struct variant *array, size_t len)
{
    //TODO
    return 0; //TO DELETE
}

int variant_sum(const struct variant *array, size_t len)
{
    //TODO
    return 0; //TO DELETE
}

