#include "variant.h"

int main(void)
{
    //TEST YOUR CODE HERE

    return 0;
}
