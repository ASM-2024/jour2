#ifndef MACROS_H
#define MACROS_H

#define DECLARE_AND_SET(TYPE, NAME, VALUE)
//TODO

#endif
